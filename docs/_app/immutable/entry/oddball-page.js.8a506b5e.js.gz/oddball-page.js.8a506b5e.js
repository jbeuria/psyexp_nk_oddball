import"../chunks/store.8b8872e6.js";import{l as a,s as l}from"../chunks/_page.badf1231.js";export{a as load,l as ssr};
