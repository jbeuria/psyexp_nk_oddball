import{_ as r}from"./_page.badf1231.js";import{default as t}from"../entry/oddball-page.svelte.bd65062c.js";export{t as component,r as universal};
