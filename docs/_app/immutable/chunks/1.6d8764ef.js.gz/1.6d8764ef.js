import{default as t}from"../entry/error.svelte.664b0b23.js";export{t as component};
