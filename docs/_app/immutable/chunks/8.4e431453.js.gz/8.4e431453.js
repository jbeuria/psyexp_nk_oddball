import{_ as r}from"./_page.ed77219c.js";import{default as t}from"../entry/muse_helper-page.svelte.d3041fae.js";export{t as component,r as universal};
