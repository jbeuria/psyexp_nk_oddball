import{default as t}from"../entry/error.svelte.538afbb6.js";export{t as component};
