import{_ as e}from"./_page.3de20fb5.js";export{e as universal};
