import{_ as r}from"./_page.b14944b6.js";import{default as t}from"../entry/_page.svelte.32cb22d6.js";export{t as component,r as universal};
