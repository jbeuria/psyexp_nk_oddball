import{_ as e}from"./_page.29e50a4a.js";export{e as universal};
