import{_ as r}from"./_layout.95f8a586.js";import{default as t}from"../entry/layout.svelte.69e37cd4.js";export{t as component,r as universal};
