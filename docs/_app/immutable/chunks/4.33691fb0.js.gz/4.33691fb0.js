import{default as t}from"../entry/end-page.svelte.e900279c.js";export{t as component};
