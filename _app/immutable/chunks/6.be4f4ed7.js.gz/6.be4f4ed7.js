import{_ as r}from"./_page.ed77219c.js";import{default as t}from"../entry/kirtan-page.svelte.8164b9b8.js";export{t as component,r as universal};
