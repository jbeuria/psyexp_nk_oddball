import{_ as r}from"./_page.da0d156f.js";import{default as t}from"../entry/muse_helper-page.svelte.d3041fae.js";export{t as component,r as universal};
