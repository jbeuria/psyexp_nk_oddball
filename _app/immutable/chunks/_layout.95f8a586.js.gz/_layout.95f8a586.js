const e=!1,r=!0,s=Object.freeze(Object.defineProperty({__proto__:null,prerender:!0,ssr:!1},Symbol.toStringTag,{value:"Module"}));export{s as _,r as p,e as s};
