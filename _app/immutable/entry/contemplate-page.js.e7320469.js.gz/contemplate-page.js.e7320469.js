import"../chunks/store.8b8872e6.js";import{l}from"../chunks/_page.e72e9c6d.js";export{l as load};
