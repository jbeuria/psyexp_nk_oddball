import{_ as r}from"./_page.5eee0b91.js";import{default as t}from"../entry/lecture-page.svelte.6ac1ae7e.js";export{t as component,r as universal};
