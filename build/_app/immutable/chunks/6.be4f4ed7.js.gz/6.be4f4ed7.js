import{_ as r}from"./_page.da0d156f.js";import{default as t}from"../entry/kirtan-page.svelte.8164b9b8.js";export{t as component,r as universal};
