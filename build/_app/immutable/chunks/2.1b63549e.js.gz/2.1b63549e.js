import{_ as r}from"./_page.b14944b6.js";import{default as t}from"../entry/_page.svelte.ed1c7da4.js";export{t as component,r as universal};
