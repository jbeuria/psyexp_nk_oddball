import{_ as e}from"./_page.9520fb8c.js";export{e as universal};
