import{_ as r}from"./_page.e72e9c6d.js";import{default as t}from"../entry/contemplate-page.svelte.9c4e986e.js";export{t as component,r as universal};
