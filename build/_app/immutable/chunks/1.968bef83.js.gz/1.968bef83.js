import{default as t}from"../entry/error.svelte.def8dca5.js";export{t as component};
